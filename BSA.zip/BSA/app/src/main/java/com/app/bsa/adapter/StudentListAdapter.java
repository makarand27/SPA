package com.app.bsa.adapter;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.telephony.SmsManager;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModel;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bsa.ApplicationViewModel;
import com.app.bsa.R;
import com.app.bsa.StudentMaintActivity;
import com.app.bsa.StudentsListActivity;
import com.app.bsa.service.repository.AppConstants;
import com.app.bsa.service.repository.Student;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import static com.app.bsa.service.repository.AppConstants.PERMISSION_REQUEST_CODE;

public class StudentListAdapter extends RecyclerView.Adapter {


    private HashMap<String, Student> mDataMap = new HashMap<String, Student>();
    private ArrayList<String> mDataset = new ArrayList<>();
    private HashMap<String,Integer> mSelectedStudents = new HashMap<>();
    private ApplicationViewModel mViewModel;
    private boolean[] mChecked;
    boolean mInSelectionMode = false;
    ActionMode mCAB = null;
    private Context mContext;
    int mCurMM = 0;
    int mCurYYYY =0;

    public StudentListAdapter(Context vContext, ApplicationViewModel vVModel){
        mContext = vContext;
        mViewModel = vVModel;
    }

    public HashMap<String,Integer> getSelectedStudents(){
        return mSelectedStudents;
    }

    public void setData(HashMap<String, Student> vStudentMap){
        mDataset.clear();
        mDataMap.clear();
        mDataMap.putAll(vStudentMap);
        mDataset.addAll(vStudentMap.keySet());
        mChecked = new boolean[mDataset.size()];
        mSelectedStudents.clear();

        Collections.sort(mDataset);

        Calendar cal1 = Calendar.getInstance();
        mCurMM = cal1.get(Calendar.MONTH)+1;
        mCurYYYY = cal1.get(Calendar.YEAR);
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        final View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new SimpleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if(mDataset.size()>0){
            ((SimpleViewHolder) holder).bindData((String)mDataset.get(position),position);
        }
    }

    public void selectItem(Integer vPosition, String vStudentId){
        mChecked[vPosition] = true;
        mSelectedStudents.put(vStudentId, vPosition);
    }
    public void deSelectItem(Integer vPosition, String vStudentId){
        mChecked[vPosition] = false;
        mSelectedStudents.remove(vStudentId);
        if(mSelectedStudents.size() == 0){
            resetAllSelections();
        }
    }
    public void resetAllSelections(){
       Arrays.fill(mChecked,false);
       mSelectedStudents.clear();
       mInSelectionMode = false;
       if(mCAB != null){
           mCAB.finish();
       }
    }
    public boolean isSelected(Integer vPosition){
        return mChecked[vPosition];
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    @Override
    public int getItemViewType(final int position) {
        return R.layout.list_checkbox_item;
    }


    public void updateJoiningKitPaid(){

        boolean tResult = true;

        //Validate
        StringBuilder sb = new StringBuilder();
        for (String key:mSelectedStudents.keySet()) {
            Student tStudent = mViewModel.getStudentById(key);
            if(tStudent.Joining_fee_paid){
                //Invalid selection
                Toast.makeText(mContext, mContext.getResources().getString(R.string.err_invalid_sel_joining_fee) + tStudent.getFullName(), Toast.LENGTH_SHORT).show();
                return;
            }
        }

        new android.app.AlertDialog.Builder(mContext)
                .setTitle("Update Joining Kit payment")
                .setMessage("Confirm update?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {

                        StringBuilder sb = new StringBuilder();
                        for (String key:mSelectedStudents.keySet()) {
                            final Student tStudent = mViewModel.getStudentById(key);

                            if (tStudent == null) {
                                //Error fetching data
                                //USers need to verify after action since there is no feedback currently - async

                            } else {

                                if (tStudent.Joining_fee_paid) {
                                    //Already paid - cant update - should not happen
                                } else {
                                    //update and send SMS
                                    mViewModel.updateJoiningKitPaid(tStudent.Id,true);
                                    sb.append(tStudent.First_name).append(",");
                                }
                            }
                        }

                        //Send SMS
                        if(sb.length() > 0){
                            SmsManager sms = SmsManager.getDefault();

                            String sendsmsText = "Joining Kit fees received from "+ sb.toString();
                            try {

                                sms.sendTextMessage(mContext.getResources().getString(R.string.sms_ph_no), null, sendsmsText, null, null);
                            }catch(Exception e){
                                //TODO -
                                Log.d("SMS ","Failed sending joining kit SMS");
                            }
                        }

                    }})
                .setNegativeButton(android.R.string.no, null).show();

    }



    public class SimpleViewHolder extends RecyclerView.ViewHolder {
        private TextView NameTextView;
        private TextView LevelTextView;
        private ImageView mCheckImage;

        public SimpleViewHolder(final View itemView) {
            super(itemView);
            NameTextView = itemView.findViewById(R.id.name);
            LevelTextView = itemView.findViewById(R.id.level);
            mCheckImage = itemView.findViewById(R.id.img_check);
        }



        public void bindData(final String vName, final int position) {

            if(mDataset.size() > 0) {

                boolean tIsOverdue = Student.isFeeOverdue(mDataMap.get(vName), mCurMM, mCurYYYY);
                int tColor = Color.BLACK;
                final String tStudentId = mDataMap.get(vName).Id;


                if (tIsOverdue) {
                    tColor = Color.RED;
                }


                if(!mInSelectionMode){
                    mCheckImage.setVisibility(View.INVISIBLE);
                }

                NameTextView.setTextColor(tColor);
                LevelTextView.setTextColor(tColor);

                LevelTextView.setText(mDataMap.get(vName).Level);
                NameTextView.setText(mDataMap.get(vName).getFullName());

                if (isSelected(position)) {
                    this.itemView.setBackgroundColor(Color.CYAN);
                } else {
                    this.itemView.setBackgroundColor(Color.TRANSPARENT);
                }

                this.itemView.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {

                        if(mInSelectionMode){
                            if (!isSelected(position)) {
                                //select item
                                selectItem(position,tStudentId);
                                v.setBackgroundColor(Color.CYAN);
                                mCheckImage.setVisibility(View.VISIBLE);


                            }else{
                                deSelectItem(position,tStudentId);
                                v.setBackgroundColor(Color.TRANSPARENT);
                                mCheckImage.setVisibility(View.INVISIBLE);
                            }

                        }else{
                            //Non-Selection action mode
                            if (!isSelected(position)) {
                                Intent tMaintIntent = new Intent(mContext, StudentMaintActivity.class);
                                tMaintIntent.putExtra(AppConstants.INTENT_KEY.ACTION, AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW);
                                tMaintIntent.putExtra(AppConstants.INTENT_KEY.STUDENT_ID, tStudentId);
                                mContext.startActivity(tMaintIntent);
                            }
                        }
                    }
                });

                this.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        mCAB = ((AppCompatActivity) v.getContext()).startSupportActionMode(actionModeCallbacks);
                        if (!isSelected(position)) {
                            selectItem(position, tStudentId);
                            (v).setBackgroundColor(Color.CYAN);
                            mCheckImage.setVisibility(View.VISIBLE);
                        } else {
                            deSelectItem(position, tStudentId);
                            (v).setBackgroundColor(Color.TRANSPARENT);
                            mCheckImage.setVisibility(View.INVISIBLE);
                        }
                        return true;
                    }

                });
            }

        }

    }



    //CAB
    private ActionMode.Callback actionModeCallbacks = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {

            MenuInflater inflater = new MenuInflater( mContext);
            inflater.inflate(R.menu.menu_studentlist_context, menu);

            if(!mViewModel.getSMSPermission()){
                (menu.findItem(R.id.itemfee1)).setVisible(false);
                (menu.findItem(R.id.itemfee3)).setVisible(false);
                (menu.findItem(R.id.itemfee6)).setVisible(false);
            }else{
                if(!mViewModel.isAdminUser()){
                    (menu.findItem(R.id.itemfee1)).setVisible(false);
                    (menu.findItem(R.id.itemfee3)).setVisible(false);
                    (menu.findItem(R.id.itemfee6)).setVisible(false);                }
            }
           mInSelectionMode = true;
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {

            switch (item.getItemId()) {

                case R.id.itemfee1:
                    if(!mViewModel.isAdminUser()){
                        Toast.makeText(mContext, "user_not_permitted", Toast.LENGTH_SHORT).show();
                    } else {
                            Set keySet = mSelectedStudents.keySet();
                            Iterator keyIterator = keySet.iterator();
                            while (keyIterator.hasNext()) {
                                String tStudentId = (String)keyIterator.next();
                                if(mViewModel.getSMSPermission()){
                                    sendSMSTextForFee(1, tStudentId);
                                }

                            }
                    }

                    break;

                case R.id.itemfee6:
                    if(!mViewModel.isAdminUser()){
                        Toast.makeText(mContext, "user_not_permitted", Toast.LENGTH_SHORT).show();
                    } else {
                        Set keySet = mSelectedStudents.keySet();
                        Iterator keyIterator = keySet.iterator();
                        while (keyIterator.hasNext()) {
                            String tStudentId = (String)keyIterator.next();
                            if(mViewModel.getSMSPermission()) {
                                sendSMSTextForFee(6, tStudentId);
                            }
                        }
                    }

                    break;
                case R.id.itemfee3:
                    if(!mViewModel.isAdminUser()){
                        Toast.makeText(mContext, "user_not_permitted", Toast.LENGTH_SHORT).show();
                    } else {
                        Set keySet = mSelectedStudents.keySet();
                        Iterator keyIterator = keySet.iterator();
                        while (keyIterator.hasNext()) {
                            String tStudentId = (String)keyIterator.next();
                            if(mViewModel.getSMSPermission()) {
                                sendSMSTextForFee(3, tStudentId);
                            }
                        }
                    }

                    break;
            }
            mode.finish();
            return true;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

            //clear selection list
            // Clear flag for selection mode
            //Tell adapter to refresh
            resetAllSelections();
            mInSelectionMode = false;
            notifyDataSetChanged();
        }

        private void sendSMSTextForFee(final int vPeriod, String vStudentId){

            final Student tStudent = mViewModel.getStudentById(vStudentId);
            String tContact ="";
            String tSMSTextString = "";



            if(tStudent == null){
                //Error fetching data
                Toast.makeText(mContext, "Could not find data. Contact details not available", Toast.LENGTH_SHORT).show();
                return;
            }else {
                tContact = tStudent.Contact;
                if (tContact.isEmpty()) {
                    //No point proceeding
                    Toast.makeText(mContext, "Contact details not available", Toast.LENGTH_SHORT).show();
                    return;
                }

                String tName = tStudent.getFullName();

                String[] replaceStr = {tName, tStudent.Batch_name, vPeriod + ""};
                String[] paramHolder = {"$lstName", "$batchStr", "$period"};
                tSMSTextString = TextUtils.replace(mContext.getResources().getString(R.string.msg_fee_rcvd), paramHolder, replaceStr).toString();

            }

            final String SMSNumber = tContact;
            final String tSMSText = tSMSTextString;

            AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
            builder.setMessage(Html.fromHtml(tSMSText));
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    SmsManager sms = SmsManager.getDefault();
                    sms.sendTextMessage(SMSNumber, null, tSMSText, null, null);

                    updateFeeStatus(tStudent, vPeriod);
                    Toast.makeText(mContext , "Expiry date of subscription is extended ", Toast.LENGTH_SHORT).show();

                }
            });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }


        private void updateFeeStatus(Student vStudent,int vExtension){

            try{
                //String tName = vStudent.getFullName();
                int tMonthMM = Integer.parseInt(vStudent.Fee_status.substring(0,2));
                int tYearYYYY = Integer.parseInt(vStudent.Fee_status.substring(3,7));

                if( (tMonthMM + vExtension )>12 ){

                    tMonthMM = (tMonthMM +vExtension)%12;
                    tYearYYYY++;

                }else {

                    tMonthMM  = tMonthMM + vExtension;
                }
                String tNewFeeValue = String.format("%02d/%04d",tMonthMM,tYearYYYY);

                mViewModel.updateFeeStatus(vStudent.Id, tNewFeeValue);

                Log.d("Students_List",tNewFeeValue);

            }catch(NumberFormatException e){
                //No action to be taken currently
                //users to verify if updates are done
                Toast.makeText(mContext, "Something went wrong in update - please verify data!", Toast.LENGTH_SHORT).show();
            }

        }

    };
}
