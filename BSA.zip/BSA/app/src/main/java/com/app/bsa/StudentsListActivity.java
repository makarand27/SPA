package com.app.bsa;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.app.bsa.adapter.StudentListAdapter;
import com.app.bsa.service.repository.AppConstants;
import com.app.bsa.service.repository.Student;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

public class StudentsListActivity extends AppCompatActivity {

    private ApplicationViewModel mViewModel;
    private StudentListAdapter mAdapter = null;
    private String mBatchName = "";
    private static StringBuffer newAdmission = new StringBuffer("\nNew Admission:\n");
    private static BroadcastReceiver smsSentReceiver;
    boolean mHasSMSPermission = false;

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        mBatchName = intent.getExtras().getString(AppConstants.INTENT_KEY.BATCH);

        mViewModel = ViewModelProviders.of(this).get(ApplicationViewModel.class);

        if (mAdapter == null) {

            mAdapter = new StudentListAdapter(this, mViewModel);

            mViewModel.getStudentsInBatch(mBatchName).observe(this, new Observer<HashMap<String, Student>>() {
                @Override
                public void onChanged(final HashMap<String, Student> vStudentMap) {
                    if(vStudentMap!= null){
                        mAdapter.setData(vStudentMap);
                        mAdapter.notifyDataSetChanged();
                    }
                }
            });
        }

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView = findViewById(R.id.rcyr_students_list);
        mRecyclerView.setLayoutManager(mLayoutManager);
        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);
        mRecyclerView.setAdapter(mAdapter);

        registerForContextMenu(mRecyclerView);

        FloatingActionButton fab = findViewById(R.id.fab_search);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSearch();
            }
        });
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        if(mViewModel.getSMSPermission()) {
            //enable actions that require SMS
            (menu.findItem(R.id.action_remind)).setVisible(false);
            (menu.findItem(R.id.action_report_attendance)).setVisible(false);
            (menu.findItem(R.id.action_joining_kit_paid)).setVisible(false);
        }else{
            if(!mViewModel.isAdminUser()){
                (menu.findItem(R.id.action_remind)).setVisible(false);
            }

        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this); //TODO: Deprecated

        switch (item.getItemId()) {

            case R.id.action_report_attendance:

                if(!prefs.getBoolean(getResources().getString(R.string.action_sms),true)){
                    Toast.makeText(this, prefs.getString("app_SMS_enable_alert",""), Toast.LENGTH_SHORT).show();
                } else{
                    if(mViewModel.getSMSPermission()){
                        sendAttendanceSMS();
                    }else{
                        Toast.makeText(this,"Please enable SMS permissions",Toast.LENGTH_SHORT).show();
                    }
                }

                return true;
            case R.id.action_report_new:
                addStudents();
                return true;

            case R.id.action_joining_kit_paid:

                if(mAdapter.getSelectedStudents().size() == 0){
                    Toast.makeText(this, "Please select Students for action", Toast.LENGTH_SHORT).show();
                    return true;
                }
                if(!prefs.getBoolean(getResources().getString(R.string.action_sms),true)){
                    Toast.makeText(this, prefs.getString("app_SMS_enable_alert",""), Toast.LENGTH_SHORT).show();
                } else{
                    if(mViewModel.getSMSPermission()){
                        //Assume need to send SMS as part of updating details
                        mAdapter.updateJoiningKitPaid();
                    }else{
                        Toast.makeText(this,"Please enable SMS permissions",Toast.LENGTH_SHORT).show();
                    }

                }

                return true;
            case R.id.action_remind :

                if(!mViewModel.isAdminUser()){
                    Toast.makeText(this, prefs.getString("user_not_permitted",""), Toast.LENGTH_SHORT).show();
                } else {
                    if(!prefs.getBoolean(getResources().getString(R.string.action_sms),true)){
                        Toast.makeText(this, prefs.getString("app_SMS_enable_alert",""), Toast.LENGTH_SHORT).show();
                    } else {
                        if(mViewModel.getSMSPermission()){
                            sendReminder();
                        }else{
                            Toast.makeText(this,"Please enable SMS permissions",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                return true;
            case R.id.action_settings :
                //startActivity(new Intent(this, SettingsPrefActivity.class));
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }


    private void onClickSearch(){
        Intent tSearchIntent = new Intent(this, SearchActivity.class);
        this.startActivity(tSearchIntent);
    }
    private void addStudents(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Students");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT );
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                newAdmission.append(input.getText().toString()+"\n");
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                dialog.dismiss();
            }
        });

        builder.show();
    }


    private void sendReminder(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        final HashMap<String,String > tStudentsToSMS = new HashMap<String,String>();
        StringBuilder tSBStudentsWithoutContact = new StringBuilder();
        //tSBStudentsWithoutContact.append("\n Students without valid contacts are ");
        for (String key:mAdapter.getSelectedStudents().keySet()) {

            String listItemName =key ;

            String tContact = "";
            String tName = "";

            final Student tStudent = mViewModel.getStudentById(listItemName);

            if(tStudent == null){
                //Error fetching data
                tSBStudentsWithoutContact.append(listItemName).append(", ");

            }else {
                tContact = tStudent.Contact;
                if (tContact.isEmpty()) {
                    tSBStudentsWithoutContact.append(listItemName).append(", ");
                }else{
                    tName = tStudent.First_name;
                    tStudentsToSMS.put(tName,tContact);
                }

            }

        }
        String tTitle = "Reminder To students";
        if(tSBStudentsWithoutContact.length() != 0){
            tTitle = "Reminder To students" + "\nStudents without contacts are "+tSBStudentsWithoutContact.toString();
        }

        builder.setTitle(tTitle);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT );
        builder.setView(input);
        builder.setPositiveButton("REMIND", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (input.getText().toString().equals("Reminder To students")) { //TODO remove
                    for (String key:tStudentsToSMS.keySet()) {
                        SmsManager sms = SmsManager.getDefault();

                        String[] paramHolder = {"$kidName"};
                        String[] replaceStr ={key};
                        String sendsmsText = TextUtils.replace(getString(R.string.key_reminder_msg),paramHolder, replaceStr).toString();
                        int tCount = sendsmsText.length();
                        try {

                            sms.sendTextMessage (tStudentsToSMS.get(key), null, sendsmsText, null, null);

                            final ProgressDialog dialog1 = new ProgressDialog(getApplicationContext());
                            dialog1.setTitle("Sending SMS..." + tCount);
                            dialog1.setMessage("Please wait.");
                            dialog1.setIndeterminate(true);
                            dialog1.setCancelable(false);
                            dialog1.show();

                            long delayInMillis = 1500;
                            Timer timer = new Timer();
                            timer.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                    dialog1.dismiss();
                                }
                            }, delayInMillis);

                        } catch (Exception e) {
                            Log.d("SMS SEND","SMS SENDING INTERRUPTED");
                            e.printStackTrace();
                        }

                    }
                }
                tStudentsToSMS.clear();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                dialog.dismiss();
            }
        });

        builder.show();
    }

    private void sendAttendanceSMS(){

        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this); //TODO: Deprecated

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final StringBuilder tSB = new StringBuilder("Students For Batch:" + mBatchName +"\n");

        for (String key:mAdapter.getSelectedStudents().keySet()) {

            tSB.append((mViewModel.getStudentById(key)).getFullName() +"\n");
        }

        builder.setMessage(tSB.append(newAdmission));
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                smsSentReceiver= new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {

                        Log.d("SMS SENT", "SMS onReceive intent received.");

                        switch (getResultCode()) {
                            case Activity.RESULT_OK:
                                Toast.makeText(getApplicationContext() , getResources().getString(R.string.sms_msg_success), Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                                Toast.makeText(context,
                                        "Failed to Send message :: GENERIC ERROR",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_NO_SERVICE:
                                Toast.makeText(context,
                                        "Failed to Send message :: NO_SERVICE",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_NULL_PDU:
                                Toast.makeText(context,
                                        "Failed to Send message :: NULL PDU",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case SmsManager.RESULT_ERROR_RADIO_OFF:
                                Toast.makeText(context,
                                        "Failed to Send message :: NETWORK NOT FOUND",
                                        Toast.LENGTH_SHORT).show();
                                break;
                        }
                        unregisterReceiver(smsSentReceiver);
                    }
                };

                registerReceiver(smsSentReceiver, new IntentFilter("SMS_SENT"));
                SmsManager sms = SmsManager.getDefault();
                ArrayList<String> parts = sms.divideMessage(tSB.toString());
                ArrayList<PendingIntent> sentIntents = new ArrayList<PendingIntent>();
                for (int i = 0; i < parts.size(); i++) {
                    sentIntents.add(PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(
                            "SMS_SENT"), 0));
                }

                sms.sendMultipartTextMessage(getResources().getString(R.string.sms_ph_no),null,parts,sentIntents,null);

                newAdmission=new StringBuffer("\nNEW Admission:\n");

                mAdapter.resetAllSelections();

            }
        });

        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //TODO?
            }
        });
        AlertDialog dialog = builder.create();

        dialog.show();
    }


}
