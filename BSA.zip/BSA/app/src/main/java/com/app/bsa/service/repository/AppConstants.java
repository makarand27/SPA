package com.app.bsa.service.repository;

public class AppConstants {

    public class INTENT_KEY{
        public static final String BATCH = "BATCH";
        public static final String ACTION = "ACTION";
        public static final String STUDENT_ID = "STUDENT_ID";
        public static final String STUDENT_NAME = "STUDENT_NAME";
    }
    public class INTENT_VALUES{
        public static final String MAINT_ACTION_VIEW = "MAINT_ACTION_VIEW";
        public static final String MAINT_ACTION_ADD = "MAINT_ACTION_ADD";
        public static final String MAINT_ACTION_EDIT = "MAINT_ACTION_EDIT";
    }

    public static final int PERMISSION_REQUEST_CODE = 100;
}
