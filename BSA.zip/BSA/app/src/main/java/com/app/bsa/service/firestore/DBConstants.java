package com.app.bsa.service.firestore;

public class DBConstants {


    public static final String SOURCE_CACHE = "Cache";
    public static final String SOURCE_SERVER = "Server";
    public static final String SOURCE_NOTSET = "NotSet";


    public static final String STUDENT_PATH = "StudentDev";
    public class STUDENT{
        public static final String FIRST_NAME = "First_name";
        public static final String LAST_NAME = "Last_name";
        public static final String CONTACT = "Contact";
        public static final String FEE_STATUS = "Fee_status";
        public static final String LEVEL = "Level";
        public static final String BATCH_NAME = "Batch_name";
        public static final String CUSTOM_FEE = "Custom_fee";
        public static final String JOINING_FEE_PAID = "Joining_fee_paid";

    }

    public static final String ADMIN_PATH = "Admin";
    public class ADMIN{
        public static final String ID = "id";
    }

    public static final String FEES_PATH = "Fees";
    public class FEES{
        public static final String FEE_LEVEL = "Fee_level";
        public static final String FEE_AMOUNT = "Fee_amount";

        //Not a field = default fee value
        public static final String DEFAULT = "Default";

    }

}
