package com.app.bsa.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.bsa.R;
import com.app.bsa.StudentsListActivity;
import com.app.bsa.service.repository.AppConstants;

import java.util.ArrayList;

public class BatchListAdapter extends RecyclerView.Adapter {


    private ArrayList<String> mDataset = new ArrayList();
    Context mContext;

    public BatchListAdapter(Context vContext){
        mContext= vContext;
    }

    public void refresh(){
        ArrayList<String> tTemp = new ArrayList<>();
        tTemp.addAll(mDataset);
        mDataset.clear();
        mDataset.addAll(tTemp);
    }

    public void setData(ArrayList<String> vBatchNames){
        mDataset.clear();
        mDataset.addAll(vBatchNames);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        final View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new SimpleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ((SimpleViewHolder) holder).bindData((String)mDataset.get(position));
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    @Override
    public int getItemViewType(final int position) {
        return R.layout.list_item;
    }



    public class SimpleViewHolder extends RecyclerView.ViewHolder {
        private TextView batchTextView;

        public SimpleViewHolder(final View itemView) {
            super(itemView);
            batchTextView = itemView.findViewById(R.id.name);
        }



        public void bindData(final String vValue) {

            batchTextView.setText(vValue);

            batchTextView.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    Intent myIntent = new Intent(v.getContext(), StudentsListActivity.class);
                    myIntent.putExtra(AppConstants.INTENT_KEY.BATCH, ((TextView) v).getText().toString());
                    mContext.startActivity(myIntent);
                }
            });

        }
    }
}
