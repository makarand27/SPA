package com.app.bsa.service.firestore;


import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bsa.service.repository.Student;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.common.collect.ListMultimap;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.ArrayListMultimap;
import com.google.firebase.firestore.core.ArrayContainsAnyFilter;


public class FirestoreData{


    private static final HashMap<String,String> mAdminUsers = new HashMap();

    private final HashMap<String, Student> mStudentIdToStudentMap = new HashMap<>();
    private final HashMap<String, Student> mStudenNamesToStudentMap = new HashMap<>();
    private final HashMap<String,String> mStudentNametoIdMap = new HashMap<String,String>();

    private final ListMultimap<String, Student> mBatchNameToStudentsMap = ArrayListMultimap.create();

    private static HashMap<String, Double> mFeeMap = new HashMap<>();
    private static final HashMap<String, String> mFeeLevelToFeeIdMap = new HashMap<>();
    private static List<CharSequence> mSortedFeeNameList = new ArrayList<>();

    private static FirebaseAuth mAuth;
    private static final int RC_SIGN_IN = 9001;
    private static final String TAG = "Firestore_DataRepo";
    private static FirestoreData mFireStoreData = null;

    private static MutableLiveData<String> mCurrentUser = new MutableLiveData<>();
    private MutableLiveData<ArrayList<String>> mBatchList = new MutableLiveData<>();
    private MutableLiveData<HashMap<String,Student>> mStudentsInBatch = new MutableLiveData<>();


    private FirestoreData(){
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser.setValue(mAuth.getCurrentUser().getEmail());
        LoadRoleData();
        LoadFeeData();
        LoadStudentData();
    }

    public static FirestoreData getInstance(){
        mAuth = FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser() == null) return null;

        if (mFireStoreData == null ) {
            mFireStoreData = new FirestoreData();
        }
        return mFireStoreData;

    }
    public boolean isAdminUser(){
        if(mAuth.getCurrentUser()!= null){
            return mAdminUsers.containsValue(mAuth.getCurrentUser().getEmail());
        }
        else{
            return false;
        }
    }

    private static void LoadRoleData(){
        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        mAdminUsers.clear();

        db.collection(DBConstants.ADMIN_PATH)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String tUserEmailId = document.getString(DBConstants.ADMIN.ID);
                                mAdminUsers.put(document.getId(),tUserEmailId);
                                Log.d(TAG, "Roles loaded : " + document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.d(TAG, "Error getting Role data: ", task.getException());
                        }
                    }
                });
    }

    public HashMap<String, Double> getFeeData(){

        return mFeeMap;
    }


    public List<CharSequence> getSortedFeeNameList(){
        if(mSortedFeeNameList.size() == 0){
            ArrayList<String> tFeeLevelNames = new ArrayList(mFeeMap.keySet());
            //Only for display
            tFeeLevelNames.add(""); //Add dummy blank entry to handle no level cases
            Collections.sort(tFeeLevelNames);
            mSortedFeeNameList = new ArrayList(tFeeLevelNames);
        }

        return mSortedFeeNameList;
    }

    public void deleteFee(String vFeeLevel){
        if(!mFeeLevelToFeeIdMap.containsKey(vFeeLevel)) {return;}

        final String tFeeId = mFeeLevelToFeeIdMap.get(vFeeLevel);

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        if(tFeeId != null){
            db.collection(DBConstants.FEES_PATH).document(tFeeId)
                    .delete()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "Fee successfully deleted for "+tFeeId);
                            LoadFeeData();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error deleting fee for " + tFeeId, e);
                        }
                    });
        }
    }


    public void updateFee(String vFeeLevel, Double vFeeValue){

        if(!mFeeLevelToFeeIdMap.containsKey(vFeeLevel)) {return;}

        final String tFeeId = mFeeLevelToFeeIdMap.get(vFeeLevel);

        FeesDao tDao = new FeesDao();
        tDao.Fee_level = vFeeLevel;
        tDao.Fee_amount = vFeeValue;

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference tDocumentRef = db.collection(DBConstants.FEES_PATH).document(tFeeId);
        if(tDocumentRef != null){
            tDocumentRef.update(DBConstants.FEES.FEE_AMOUNT,vFeeValue)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "Fees successfully updated for : "+tFeeId);
                            LoadFeeData();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating fees for : "+ tFeeId, e);
                        }
                    });
        }

    }
    public void addFee(String vFeeLevel, Double vFeeValue){

        if(mFeeMap.containsKey(vFeeLevel)) {return;}

        FeesDao tDao = new FeesDao();
        tDao.Fee_level = vFeeLevel;
        tDao.Fee_amount = vFeeValue;

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference newBatchRef = db.collection(DBConstants.FEES_PATH).document();
        newBatchRef.set(tDao);
        LoadFeeData();

    }
    private static void LoadFeeData(){
        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        mFeeMap.clear();
        mFeeLevelToFeeIdMap.clear();
        mSortedFeeNameList.clear();

        CollectionReference feesRef = db.collection(DBConstants.FEES_PATH);
        Query query = feesRef.orderBy(DBConstants.FEES.FEE_LEVEL);

        query.get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String tFeeLevel = document.getString(DBConstants.FEES.FEE_LEVEL);
                                Double tFeeAmount = document.getDouble(DBConstants.FEES.FEE_AMOUNT);
                                mFeeMap.put(tFeeLevel,tFeeAmount);
                                mFeeLevelToFeeIdMap.put(tFeeLevel,document.getId());
                                Log.d(TAG, "Fees loaded : " + document.getId() + " => " + document.getData());
                            }

                        } else {
                            Log.d(TAG, "Error getting Fee data: ", task.getException());
                        }
                    }
                });
    }


    public final void reloadData(){
        mStudentIdToStudentMap.clear();
        mStudentNametoIdMap.clear();
        mBatchNameToStudentsMap.clear();
        mStudenNamesToStudentMap.clear();
        mBatchList.getValue().clear();

        LoadStudentData();
    }

    private void LoadStudentData(){

        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        mBatchNameToStudentsMap.clear();

        db.collection(DBConstants.STUDENT_PATH)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            String tDataSource = task.getResult().getMetadata().isFromCache() ? DBConstants.SOURCE_CACHE : DBConstants.SOURCE_SERVER;
                            Log.d(TAG, "Loaded data from : " + tDataSource);
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Student tStudent = new Student(document.toObject(StudentDao.class));
                                tStudent.Id = document.getId();

                                mStudentIdToStudentMap.put(document.getId(),tStudent);
                                mStudentNametoIdMap.put(tStudent.First_name+" " +tStudent.Last_name,document.getId());
                                mBatchNameToStudentsMap.put(tStudent.Batch_name,tStudent);
                                mStudenNamesToStudentMap.put(tStudent.getFullName(),tStudent);

                                Log.d(TAG, document.getId() + " => " + document.getData());
                            }
                            ArrayList<String> tBatchNameList= new ArrayList<String>(mBatchNameToStudentsMap.keySet());
                            Collections.sort(tBatchNameList);
                            mBatchList.setValue(tBatchNameList);

                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });

    }

    public LiveData<ArrayList<String>> getBatchList(){

        return mBatchList;
    }

    public List<CharSequence> getSortedBatchNameList(){

        return new ArrayList(mBatchList.getValue());
    }


    public Student getStudentById(String vId){

        return mStudentIdToStudentMap.get(vId);
    }

    public HashMap<String, Student> getAllStudentData(){
        return mStudentIdToStudentMap;
    }

    public HashMap<String,Student> getStudentNamesToStudents(){
        return mStudenNamesToStudentMap;
    }


    public LiveData<HashMap<String,Student>> getStudentsInBatch(String pBatchName){

        HashMap<String,Student> tmpMap = new HashMap<String,Student>();

        List<Student> tStudentList = mBatchNameToStudentsMap.get(pBatchName);
        if(!tStudentList.isEmpty() ){
            for(Student key : tStudentList){

                tmpMap.put(key.getFullName(), key);
            }
        }
        mStudentsInBatch.setValue(tmpMap);

        return mStudentsInBatch;
    }



    private boolean validateStudent(Student vStudent){
        boolean tResult = true;
        if(vStudent.First_name == null || vStudent.First_name.isEmpty()){
            tResult = false;
        }
        if(vStudent.Batch_name == null || vStudent.Batch_name.isEmpty()){
            tResult = false;
        }

        return tResult;
    }

    public boolean addStudent(Student vStudent){

        if(!validateStudent(vStudent)){return false;}

        if(mStudentNametoIdMap.containsKey(vStudent.getFullName())) return false;

        StudentDao tStudentDao = Student.getStudentDao(vStudent);

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference newBatchRef = db.collection(DBConstants.STUDENT_PATH).document();
        newBatchRef.set(tStudentDao);
        return true;
    }

    public void deleteStudent(final String vStudentId){

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        if(vStudentId != null){
            db.collection(DBConstants.STUDENT_PATH).document(vStudentId)
                    .delete()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully deleted for "+vStudentId);
                            reloadData();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error deleting document for " + vStudentId, e);
                        }
                    });
        }
    }



    private void updateField(final String vStudentId, String vFieldName, boolean vFieldValue){

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference tDocumentRef = db.collection(DBConstants.STUDENT_PATH).document(vStudentId);
        if(tDocumentRef != null){
            tDocumentRef.update(vFieldName,vFieldValue)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated for : "+vStudentId);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document for : "+ vStudentId, e);
                        }
                    });
        }

    }

    private void updateField(final String vStudentName, String vFieldName, String vFieldValue){

        String tStudentId = mStudentNametoIdMap.get(vStudentName);

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference tDocumentRef = db.collection(DBConstants.STUDENT_PATH).document(tStudentId);
        if(tDocumentRef != null){
            tDocumentRef.update(vFieldName,vFieldValue)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated for : "+vStudentName);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document for : "+ vStudentName, e);
                        }
                    });
        }

    }
    public void updateJoiningKitPaid(String vStudentId, boolean vValue){

        updateField(vStudentId, DBConstants.STUDENT.JOINING_FEE_PAID, vValue);
    }

    public void updateFeeStatus(final String vStudentId, String vFeeStatus){

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference tDocumentRef = db.collection(DBConstants.STUDENT_PATH).document(vStudentId);
        if(tDocumentRef != null){
            tDocumentRef.update(DBConstants.STUDENT.FEE_STATUS, vFeeStatus)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated for : "+vStudentId);
                            reloadData();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document for : "+ vStudentId, e);
                        }
                    });
        }

    }



    public boolean updateStudent(Student vStudent, String vStudentId){

        if(!validateStudent(vStudent)){return false;}

        if(!mStudentNametoIdMap.containsValue(vStudentId)){ return false;}

        final Student tLocalStudent  = mStudentIdToStudentMap.get(vStudentId);

        //Find fields to update and update accordingly.
        if(tLocalStudent == null) return false; ///only existing to be updated


        Map<String,Object> tUpdateData = tLocalStudent.GetUpdateFields(vStudent);

        if(tUpdateData.size() == 0 ){ return false;}

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference newBatchRef = db.collection(DBConstants.STUDENT_PATH).document(vStudentId);
        if(newBatchRef != null){
            newBatchRef.update(tUpdateData).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Log.d(TAG, "Successfully updated data for : " + tLocalStudent.getFullName(), task.getException());
                        reloadData();
                    }
                    else{
                        //
                        Log.d(TAG, "Error updating Fee status: ", task.getException());
                    }
                }
            });
        }

        return true;

    }


    public LiveData<String> getLoggedInUser(){
        return mCurrentUser;

    }

    private void signIn(String email, String password) {

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if(currentUser != null) {
            Log.d(TAG, "Already Signed in -not attempting login.");
            return; //Already signed in
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithEmail:failure", task.getException());
                        }

                    }
                });
    }

    private void clearAllData(){
        //Called on SignOut
        mStudentIdToStudentMap.clear();
        mStudenNamesToStudentMap.clear();
        mStudentNametoIdMap.clear();
        mBatchNameToStudentsMap.clear();

        mAdminUsers.clear();
    }

    public void signOut(){
        clearAllData();
        mAuth.signOut();
    }
}