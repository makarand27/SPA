package com.app.bsa.service.repository;

import android.util.Log;

import com.app.bsa.service.firestore.FirestoreData;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


public class AccountSummary {

    int mMonthlyPaidStudents=0;
    int mMultiMonthPaidStudents = 0;
    int mInactiveStudents = 0;
    int mPaymentDueStudents = 0;
    int mCustomFeeStudents = 0;
    int mTotalStudents =0;
    double mExpectedTotal =0;
    double mActualTotal =0;


    HashMap<String,Student> mStudentMap = new HashMap<>();

    HashMap<String, Integer> mCustomFeeMapExpected = new HashMap<>();
    HashMap<String, Integer> mCustomFeeMapActual = new HashMap<>();

    HashMap<String, Integer> mLevelToStudentsCountExpectedMap = new HashMap<>();
    HashMap<String, Integer> mLevelToStudentsCountActualMap = new HashMap<>();
    String[] mInputFeeMap;
    HashMap<String, Double> mFeeMap = new HashMap<>();
    ArrayList mUnknownFeeLevels = new ArrayList();

    public AccountSummary(HashMap<String,Student> vStudentMap, String[] vFeeMap){

        mStudentMap = vStudentMap;
        mInputFeeMap = vFeeMap;
    }

    public AccountSummary(HashMap<String,Student> vStudentMap, HashMap<String, Double> vFeeMap){

        mStudentMap = vStudentMap;
        mFeeMap = vFeeMap;
    }

    public String getAccountSummary(){

        resetData();
        calculateStats();

        StringBuffer summaryText = new StringBuffer("<b><u> Monthly Summary Report </u></b><br>");

        summaryText.append("<br><b>a </b>Monthly Students:: " + mMonthlyPaidStudents+"<br>");
        summaryText.append("<b>b </b>Multi Month Students:: " + mMultiMonthPaidStudents+"<br>");
        summaryText.append("<b>c </b>Special Fees Students :: " +  mCustomFeeStudents+"<br>");
        summaryText.append("<b>d </b>UnSubscribed:: " +  mInactiveStudents+"<br>");
        summaryText.append("<b>e </b>Unpaid till date:: " +  mPaymentDueStudents+"<br>");
        summaryText.append("<b>f </b>Total (a+b+c+d):: " + mTotalStudents+"<br><br>");
        summaryText.append("Actual Total(a+b):: <b>" + mActualTotal +"</b><br><br>");
        summaryText.append("Expected Total(f-d):: <b>" + mExpectedTotal +"</b><br>");

        summaryText.append("<br><b><u>Fee Levels</u></b><br>");

        FirestoreData tFiresstoreData = FirestoreData.getInstance();

        ArrayList<String> tFeeNameList = new ArrayList(tFiresstoreData.getSortedFeeNameList());
        tFeeNameList.remove("");
        for(String tName : tFeeNameList){

            Double tFee = mFeeMap.get(tName);

            summaryText.append("<br>"+ tName + " : "+ String.format("%.0f",tFee)+ "<br>");
        }


        return summaryText.toString();
    }

    private void resetData(){
        mCustomFeeMapExpected.clear();
        mCustomFeeMapActual.clear();
        mLevelToStudentsCountExpectedMap.clear();

        mMonthlyPaidStudents=0;
        mMultiMonthPaidStudents = 0;
        mInactiveStudents = 0;
        mPaymentDueStudents = 0;
        mCustomFeeStudents = 0;
        mTotalStudents =0;
        mExpectedTotal =0;
        mActualTotal =0;

    }

    private void calculateStats() {

        mTotalStudents = mStudentMap.size();

        Calendar cal1 = Calendar.getInstance();
        int curMM = cal1.get(Calendar.MONTH)+1;
        int curYYYY = cal1.get(Calendar.YEAR);


        Set keySet = mStudentMap.keySet();
        Iterator keyIterator = keySet.iterator();

        while (keyIterator.hasNext()) {

            Student tStudent = mStudentMap.get((String) keyIterator.next());

            String tCurrentStudentFeeStatus = Student.getFeeStatus(tStudent, curMM, curYYYY);

            if (tCurrentStudentFeeStatus.equals(Student.INACTIVE)) {
                mInactiveStudents++;

            } else {
                //Active students
                if (tCurrentStudentFeeStatus.equals(Student.OVERDUE)) {

                    mPaymentDueStudents++;

                    if (!tStudent.Custom_fee.isEmpty()) {
                        try {
                            mExpectedTotal += Double.parseDouble(tStudent.Custom_fee);
                        } catch (NumberFormatException e) {
                            //ignore - bad data
                        }
                    } else {
                        mExpectedTotal += mFeeMap.get(tStudent.Level);
                    }

                } else if (tCurrentStudentFeeStatus.equals(Student.PAIDUP_MONTHLY) ) {

                    //This could be a monthly payment paid up this month or a 3 or 6 month payment made earlier ending this month
                    //but with no additional data on actual payment date stored yet - this will have to do for now
                    mMonthlyPaidStudents++;

                    if (!tStudent.Custom_fee.isEmpty()) {
                        try {
                            mExpectedTotal += Double.parseDouble(tStudent.Custom_fee);
                            mActualTotal += Double.parseDouble(tStudent.Custom_fee);

                        } catch (NumberFormatException e) {
                            //ignore - bad data
                        }
                    } else {
                        mExpectedTotal += mFeeMap.get(tStudent.Level);
                        mActualTotal += mFeeMap.get(tStudent.Level);
                    }

                } else if (tCurrentStudentFeeStatus.equals(Student.PAIDUP_MULTIMONTH)) {

                    //Two issues with this
                    //1) we dont know if this payment was maade this month
                    //2) We dont know how much many months it was paid for so we only calculate for the one month.
                    mMultiMonthPaidStudents++;

                    if (!tStudent.Custom_fee.isEmpty()) {
                        try {
                            mExpectedTotal += Double.parseDouble(tStudent.Custom_fee);
                            mActualTotal += Double.parseDouble(tStudent.Custom_fee);

                        } catch (NumberFormatException e) {
                            //ignore - bad data
                        }
                    } else {
                        mExpectedTotal += mFeeMap.get(tStudent.Level);
                        mActualTotal += mFeeMap.get(tStudent.Level);
                    }

                }
            }
        }


    }

}
