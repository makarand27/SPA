package com.app.bsa.service.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.app.bsa.service.firestore.FirestoreData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataRepository {

    private static DataRepository mDataRepository;
    private static FirestoreData mFirestoreData;


    private DataRepository(){
        mFirestoreData = FirestoreData.getInstance();
    }

    public static DataRepository getInstance(){
        if(mDataRepository == null){
            mDataRepository =  new DataRepository();
        }
        return mDataRepository;

    }

    public void signOut(){
        mFirestoreData.signOut();
    }

    public void reloadData(){
        mFirestoreData.reloadData();
    }

    public HashMap<String, Student> getAllStudentData(){
        return mFirestoreData.getAllStudentData();
    }

    public LiveData<ArrayList<String>>getBatchList(){
     return mFirestoreData.getBatchList();
    }

    public List<CharSequence> getSortedBatchNameList(){
        return mFirestoreData.getSortedBatchNameList();
    }

    public LiveData<String> getLoggedInUser(){
        return mFirestoreData.getLoggedInUser();
    }

    public LiveData<HashMap<String, Student>> getStudentsInBatch(String vBatchName){
        return mFirestoreData.getStudentsInBatch(vBatchName);
    }
    public HashMap<String,Student> getStudentNamesToStudents() {
        return mFirestoreData.getStudentNamesToStudents();
    }

    public boolean isAdminUser(){
        return mFirestoreData.isAdminUser();
    }

    public HashMap<String, Double> getFeeData(){

        return mFirestoreData.getFeeData();
    }
    public void addFee(String vFeeLevel, Double vFeeValue){
        mFirestoreData.addFee(vFeeLevel, vFeeValue);
    }
    public void updateFee(String vFeeLevel, Double vFeeValue){
        mFirestoreData.updateFee(vFeeLevel, vFeeValue);
    }
    public void deleteFee(String vFeeLevel){
        mFirestoreData.deleteFee(vFeeLevel);
    }

    public void updateFeeStatus(final String vStudentId, String vFeeStatus){
        mFirestoreData.updateFeeStatus(vStudentId,vFeeStatus);
    }

    public List<CharSequence> getSortedFeeNameList(){

        return mFirestoreData.getSortedFeeNameList();
    }

    public Student getStudentById(String vId){

        return mFirestoreData.getStudentById(vId);
    }

    public boolean addStudent(Student vStudent){

        return mFirestoreData.addStudent(vStudent);
    }
    public boolean updateStudent(Student vStudent, String vStudentId){
        return mFirestoreData.updateStudent(vStudent,vStudentId);
    }

     public void deleteStudent(final String vStudentId){
        mFirestoreData.deleteStudent(vStudentId);
    }

    public void updateJoiningKitPaid(String vStudentId, boolean vValue) {
        mFirestoreData.updateJoiningKitPaid(vStudentId,vValue);
    }


}
