package com.app.bsa.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.app.bsa.R;
import com.app.bsa.StudentMaintActivity;
import com.app.bsa.service.repository.Student;

public class SearchActivityAdapter extends RecyclerView.Adapter {

    private ArrayList mDataset = new ArrayList();
    private HashMap<String, Student> m_StudentDataset;



    public class SimpleViewHolder extends RecyclerView.ViewHolder {
        private TextView simpleTextView;
        private TextView batchTextView;

        public SimpleViewHolder(final View itemView) {
            super(itemView);
            simpleTextView = itemView.findViewById(R.id.student_name);
            batchTextView = itemView.findViewById(R.id.student_batch);
        }

        public void bindData(final Student vStudent) {
            simpleTextView.setText(vStudent.getFullName());
            batchTextView.setText(vStudent.Batch_name);

            simpleTextView.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    Intent tMaintIntent = new Intent(v.getContext(), StudentMaintActivity.class);
                    tMaintIntent.putExtra("ACTION", "MAINT_ACTION_VIEW");
                    tMaintIntent.putExtra("STUDENT_ID", vStudent.Id);
                    (v.getContext()).startActivity(tMaintIntent);
                }
            });

        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ((SimpleViewHolder) holder).bindData((Student)mDataset.get(position));

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }


    @Override
    public int getItemViewType(final int position) {
        return R.layout.search_name_list_item;
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public SearchActivityAdapter(HashMap<String, Student> vDataset) {
        m_StudentDataset = vDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public SearchActivityAdapter.SimpleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new SimpleViewHolder(view);
    }

    public void filter(String query){

        query = query.toLowerCase();

        mDataset.clear();
        Set keySet = m_StudentDataset.keySet();
        Iterator keyIterator = keySet.iterator();
        while (keyIterator.hasNext()) {

            String tName = (String)keyIterator.next();
            if (tName.toLowerCase().contains(query)) {

                Student tStudent = m_StudentDataset.get(tName);
                mDataset.add(tStudent);
            }
        }
        notifyDataSetChanged();
    }



}
