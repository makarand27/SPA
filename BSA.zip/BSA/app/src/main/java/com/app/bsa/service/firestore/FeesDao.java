package com.app.bsa.service.firestore;

public class FeesDao {
    public String Fee_level;
    public Double Fee_amount;
}
