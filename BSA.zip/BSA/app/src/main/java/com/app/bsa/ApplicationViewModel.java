package com.app.bsa;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.app.bsa.service.repository.DataRepository;
import com.app.bsa.service.repository.Student;
import com.google.protobuf.LazyStringArrayList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ApplicationViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private boolean mSMSPermissionAvailable = false;

    private DataRepository repo = DataRepository.getInstance();

    public void signOut(){
        repo.signOut();
    }

    public void reloadData(){
        repo.reloadData();
    }

    public void setSMSPermitted(boolean vIsPermissionAvailable){
        mSMSPermissionAvailable = vIsPermissionAvailable;
    }
    public boolean getSMSPermission(){
        return mSMSPermissionAvailable;
    }

    public HashMap<String, Student> getAllStudentData(){
        return repo.getAllStudentData();
    }
    public LiveData<ArrayList<String>> getBatchList(){

        return repo.getBatchList();
    }

    public HashMap<String,Student> getStudentNamesToStudents() {
        return repo.getStudentNamesToStudents();
    }

    public HashMap<String, Double> getFeeData(){
        return repo.getFeeData();
    }
    public void addFee(String vFeeLevel, Double vFeeValue){
        repo.addFee(vFeeLevel, vFeeValue);
    }
    public void updateFee(String vFeeLevel, Double vFeeValue){
        repo.updateFee(vFeeLevel, vFeeValue);
    }
    public void deleteFee(String vFeeLevel){
        repo.deleteFee(vFeeLevel);
    }

    public void updateFeeStatus(final String vStudentId, String vFeeStatus){
        repo.updateFeeStatus(vStudentId,vFeeStatus);
    }

    public List<CharSequence> getSortedBatchNameList(){
        return repo.getSortedBatchNameList();
    }

    public LiveData<String> getLoggedInUser(){
        return repo.getLoggedInUser();
    }


    public LiveData<HashMap<String, Student>> getStudentsInBatch(String vBatchName){
        return repo.getStudentsInBatch(vBatchName);
    }

    public boolean isAdminUser(){
        return true;//TODO
    }

    public List<CharSequence> getSortedFeeNameList(){
        return repo.getSortedFeeNameList();
    }

    public Student getStudentById(String vId){
        return repo.getStudentById(vId);
    }

    public boolean addStudent(Student vStudent){

        return repo.addStudent(vStudent);
    }
    public boolean updateStudent(Student vStudent, String vStudentId){
        return repo.updateStudent(vStudent,vStudentId);
    }

    public void deleteStudent(final String vStudentId){
        repo.deleteStudent(vStudentId);
    }

    public void updateJoiningKitPaid(String vStudentId, boolean vValue) {
        repo.updateJoiningKitPaid(vStudentId,vValue);
    }

}
