package com.app.bsa;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProviders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.app.bsa.R;


public class FeeMaintenance extends AppCompatActivity {
    private ApplicationViewModel mViewModel;
    Spinner mLevelSpinner;

    ImageButton mAddButton;
    ImageButton mUpdateButton;
    ImageButton mDeleteButton;

    EditText mFeeEdit;
    EditText mFeeAdd;
    EditText mLevelAdd;
    String mSelectedLevel="";

    ArrayAdapter<CharSequence> mLevelListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fee_maintenance);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mAddButton = findViewById(R.id.btn_fee_add);
        mDeleteButton = findViewById(R.id.btn_fee_delete);
        mUpdateButton = findViewById(R.id.btn_fee_update);
        mFeeAdd = findViewById(R.id.txt_fee_value_add);
        mFeeEdit = findViewById(R.id.txt_fee_edit);
        mLevelAdd = findViewById(R.id.txt_fee_name_add);
        mLevelSpinner = findViewById(R.id.sp_fees);

        mViewModel = ViewModelProviders.of(this).get(ApplicationViewModel.class);

        //Populate level dropdown
        final HashMap<String, Double> tFeeMap = mViewModel.getFeeData();
        ArrayList<String> tFeeLevelNames = new ArrayList(tFeeMap.keySet());
        Collections.sort(tFeeLevelNames);
        List<CharSequence> tSortedList = new ArrayList(tFeeLevelNames);

        mLevelListAdapter = new ArrayAdapter<CharSequence>(this,android.R.layout.simple_spinner_item,tSortedList);
        mLevelListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mLevelSpinner.setAdapter(mLevelListAdapter);

        mLevelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                Double tFeeAmount = tFeeMap.get(mLevelSpinner.getSelectedItem());
                if(tFeeAmount != null){
                    mFeeEdit.setText(String.format("%.0f",tFeeAmount));
                    mSelectedLevel = mLevelSpinner.getSelectedItem().toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // No action needed
            }

        });
        mLevelSpinner.setSelection(0);

        setListenerActions();
    }



    private void onClickDelete() {

        new AlertDialog.Builder(this)
                .setTitle("Delete Fee")
                .setMessage("Confirm Delete?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        mViewModel.deleteFee(mLevelSpinner.getSelectedItem().toString());
                        finish();
                    }})
                .setNegativeButton(android.R.string.no, null).show();

    }

    private void onClickAdd() {


        try{
            final Double tFeeAmount = Double.parseDouble(mFeeAdd.getText().toString());

            new AlertDialog.Builder(this)
                    .setTitle("Add Fee")
                    .setMessage("Confirm Addition?")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int whichButton) {
                            mViewModel.addFee(mLevelAdd.getText().toString(),tFeeAmount);
                            finish();
                        }})
                    .setNegativeButton(android.R.string.no, null).show();
        }catch (NumberFormatException e){
            Log.d("Fee", e.toString());
        }


    }
    private void onClickUpdate() {

        try{
            final Double tFeeAmount = Double.parseDouble(mFeeEdit.getText().toString());

            new AlertDialog.Builder(this)
                    .setTitle("Update Fee")
                    .setMessage("Confirm Update?")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int whichButton) {
                            mViewModel.updateFee(mLevelSpinner.getSelectedItem().toString(),tFeeAmount);
                            finish();
                        }})
                    .setNegativeButton(android.R.string.no, null).show();
        }catch(NumberFormatException e){
            Log.d("Fee", e.toString());
        }

    }
    private void setListenerActions() {

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onClickAdd();
            }
        });

        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickDelete();
            }
        });

        mUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {onClickUpdate();}
        });

    }

}
