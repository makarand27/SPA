package com.app.bsa.service.repository;


import android.text.TextUtils;
import android.util.Log;

import com.app.bsa.service.firestore.DBConstants;
import com.app.bsa.service.firestore.StudentDao;

import java.util.HashMap;

public class Student{

    public String First_name;
    public String Last_name;
    public String Contact;
    public String Batch_name;
    public String Level;
    public String Fee_status;
    public String Custom_fee;
    public String Id;
    public boolean Joining_fee_paid;

    public Student(){}

    public Student(StudentDao vDao){
        First_name = vDao.First_name;
        Last_name = vDao.Last_name;
        Contact = vDao.Contact;
        Batch_name = vDao.Batch_name;
        Level = vDao.Level;
        Fee_status = vDao.Fee_status;
        Custom_fee = vDao.Custom_fee;
        Joining_fee_paid = vDao.Joining_fee_paid;
    }

    public String getExportString(){

        String tJoining_fee_paid = Joining_fee_paid ?  "paid" : "pending";
        return First_name + ","
                + Last_name + ","
                + Batch_name + ","
                + Fee_status + ","
                + Contact + ","
                + Level + ","
                + Custom_fee + ","
                + tJoining_fee_paid;
    }
    public String getFullName(){
        return First_name + " " + Last_name;
    }

    public HashMap<String, Object> GetUpdateFields(Student vStudent){

        HashMap<String,Object> tUpdateData = new HashMap<>();
        //Compare
        if(!Last_name.equals(vStudent.Last_name)) tUpdateData.put(DBConstants.STUDENT.LAST_NAME,vStudent.Last_name);
        if(!First_name.equals(vStudent.First_name)) tUpdateData.put(DBConstants.STUDENT.FIRST_NAME,vStudent.First_name);
        if(!Batch_name.equals(vStudent.Batch_name)) tUpdateData.put(DBConstants.STUDENT.BATCH_NAME,vStudent.Batch_name);
        if(!Fee_status.equals(vStudent.Fee_status)) tUpdateData.put(DBConstants.STUDENT.FEE_STATUS,vStudent.Fee_status);
        if(!Contact.equals(vStudent.Contact)) tUpdateData.put(DBConstants.STUDENT.CONTACT,vStudent.Contact);
        if(!Level.equals(vStudent.Level)) tUpdateData.put(DBConstants.STUDENT.LEVEL,vStudent.Level);
        if(!Custom_fee.equals(vStudent.Custom_fee)) tUpdateData.put(DBConstants.STUDENT.CUSTOM_FEE,vStudent.Custom_fee);
        if(Joining_fee_paid != vStudent.Joining_fee_paid) tUpdateData.put(DBConstants.STUDENT.JOINING_FEE_PAID,vStudent.Joining_fee_paid);

        return tUpdateData;

    }

    public static StudentDao getStudentDao(Student vStudent){
        StudentDao tStudentDao = new StudentDao();
        tStudentDao.First_name = vStudent.First_name;
        tStudentDao.Last_name = vStudent.Last_name;
        tStudentDao.Contact = vStudent.Contact;
        tStudentDao.Batch_name = vStudent.Batch_name;
        tStudentDao.Level = vStudent.Level;
        tStudentDao.Fee_status = vStudent.Fee_status;
        tStudentDao.Custom_fee = vStudent.Custom_fee;
        tStudentDao.Joining_fee_paid = vStudent.Joining_fee_paid;
        return tStudentDao;
    }

    public static boolean isFeeOverdue(Student vStudent, int vCurrMM, int vCurrYYYY){

        boolean tOverdue = false;

        try {
            int paidYYYY = Integer.parseInt(TextUtils.substring(vStudent.Fee_status, 3, 7));
            int paidMM = Integer.parseInt(TextUtils.substring(vStudent.Fee_status, 0, 2));

            if((vCurrYYYY > paidYYYY) ||
                    ((vCurrYYYY == paidYYYY) && (vCurrMM > paidMM))){
                tOverdue =true;
            }
        }catch(NumberFormatException e){
            Log.d("Student", "Error parsing student fee status for " + vStudent.getFullName());
            tOverdue = false;
        }

        return tOverdue;
    }

    public static final String INACTIVE = "Inactive";
    public static final String OVERDUE = "overdue";
    public static final String PAIDUP_MONTHLY = "pu_monthly";
    public static final String PAIDUP_MULTIMONTH = "pu_mmonth";

    public static String getFeeStatus(Student vStudent, int vCurrMM, int vCurrYYYY){

        String tCurrentStudentFeeStatus = PAIDUP_MONTHLY;

        try{

            int paidYYYY = Integer.parseInt(TextUtils.substring(vStudent.Fee_status, 3, 7));
            int paidMM = Integer.parseInt(TextUtils.substring(vStudent.Fee_status, 0, 2));

            if (((vCurrYYYY > paidYYYY) && (paidMM < 12))
                    || ((vCurrYYYY == paidYYYY) && (paidMM <= vCurrMM - 2))) {
                //Inactive - exclude for all account purposes
                tCurrentStudentFeeStatus = INACTIVE;

            }else if (((vCurrYYYY > paidYYYY) && (paidMM == 12))
                    || ((vCurrYYYY == paidYYYY) && (paidMM == vCurrMM - 1))) {
                //overdue - assumption is these are monthly rate student as per original logic
                tCurrentStudentFeeStatus = OVERDUE;

            } else if (((vCurrYYYY == paidYYYY) && (vCurrMM < paidMM))
                    || (vCurrYYYY < paidYYYY)) {
                //advance paid
                tCurrentStudentFeeStatus = PAIDUP_MULTIMONTH;

            } else if ((vCurrYYYY == paidYYYY) &&
                    (vCurrMM == paidMM)) {
                //paid up
                tCurrentStudentFeeStatus = PAIDUP_MONTHLY;
            }

        }catch(NumberFormatException e){
            Log.d("Student", "Error parsing student fee status for " + vStudent.getFullName());
        }
        return tCurrentStudentFeeStatus;
    }



}