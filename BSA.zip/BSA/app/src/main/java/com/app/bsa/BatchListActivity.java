package com.app.bsa;

import android.Manifest;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import com.app.bsa.adapter.BatchListAdapter;
import com.app.bsa.service.repository.AccountSummary;
import com.app.bsa.service.repository.AppConstants;
import com.app.bsa.service.repository.Student;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.lifecycle.ViewModelProviders;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Environment;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import static com.app.bsa.service.repository.AppConstants.PERMISSION_REQUEST_CODE;

public class BatchListActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    private ApplicationViewModel mViewModel;
    private BatchListAdapter mAdapter = null;

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batch_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mViewModel = ViewModelProviders.of(this).get(ApplicationViewModel.class);

        mViewModel.setSMSPermitted(checkPermissionforSMS());

        if(mAdapter==null){

            mAdapter = new BatchListAdapter(this);
            mViewModel.getBatchList().observe(this, new Observer<ArrayList<String>>() {
                @Override
                public void onChanged(final ArrayList<String> vBatchNames) {
                    mAdapter.setData(vBatchNames);
                    mAdapter.notifyDataSetChanged();
                }
            });
        }
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView = findViewById(R.id.rcyr_batch_list);
        mRecyclerView.setLayoutManager(mLayoutManager);
        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);
        mRecyclerView.setAdapter(mAdapter);

        FloatingActionButton fab = findViewById(R.id.fab_search);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSearch();
            }
        });
    }


    @Override
    public void onRefresh() {
        // This method performs the actual data-refresh operation.
        // The method calls setRefreshing(false) when it's finished.
        mViewModel.reloadData();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        (menu.findItem(R.id.action_export)).setVisible(mViewModel.isAdminUser());
        (menu.findItem(R.id.action_add_student)).setVisible(mViewModel.isAdminUser());
        (menu.findItem(R.id.action_settings)).setVisible(mViewModel.isAdminUser());
        (menu.findItem(R.id.action_account_summary)).setVisible(mViewModel.isAdminUser());
        (menu.findItem(R.id.action_fees)).setVisible(mViewModel.isAdminUser());


        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;

    }

    private void onClickSearch(){
        Intent tSearchIntent = new Intent(this, SearchActivity.class);
        this.startActivity(tSearchIntent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_sign_out :
                new AlertDialog.Builder(this)
                        .setTitle("Signing out...")
                        .setMessage("Are you sure you want to sign out?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                mViewModel.signOut();
                                startActivity(new Intent(BatchListActivity.this, SignInActivity.class));
                            }})
                        .setNegativeButton(android.R.string.no, null).show();

                return true;

            case R.id.action_settings :
                /*
                startActivity(new Intent(BatchListActivity.this, SettingsPrefActivity.class));
                 */
                return true;

            case R.id.swiperefresh :
                mViewModel.reloadData();
                return true;

            case R.id.action_account_summary :

                if(!mViewModel.isAdminUser()){
                    Toast.makeText(this, "Permission not available", Toast.LENGTH_SHORT).show();
                } else{
                    showAccountSummary();
                }

                return true;

            case R.id.action_fees:

                if(!mViewModel.isAdminUser()){

                    Toast.makeText(this, "Permission not available", Toast.LENGTH_SHORT).show();
                } else{
                    Intent tMaintIntent = new Intent(this, FeeMaintenance.class);
                    tMaintIntent.putExtra(AppConstants.INTENT_KEY.ACTION, AppConstants.INTENT_VALUES.MAINT_ACTION_ADD);
                    this.startActivity(tMaintIntent);
                }

                return true;
            case R.id.fab_search:

                Intent tSearchIntent = new Intent(this, SearchActivity.class);
                this.startActivity(tSearchIntent);

                return true;
            case R.id.action_add_student :

                if(!mViewModel.isAdminUser()){

                    Toast.makeText(this, "Permission not available", Toast.LENGTH_SHORT).show();
                } else{
                    Intent tMaintIntent = new Intent(this, StudentMaintActivity.class);
                    tMaintIntent.putExtra(AppConstants.INTENT_KEY.ACTION, AppConstants.INTENT_VALUES.MAINT_ACTION_ADD);
                    this.startActivity(tMaintIntent);
                }

                return true;

            case R.id.action_export :

                if(!mViewModel.isAdminUser()){

                    Toast.makeText(this, "Permission not available", Toast.LENGTH_SHORT).show();

                } else{

                    String state = Environment.getExternalStorageState();
                    if (Environment.MEDIA_MOUNTED.equals(state)) {
                        if(!checkFilePermission()) {
                            requestFilePermission();
                        }
                        else{
                            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd-HH-mm-ss");
                            Date tDate = new Date();
                            String tFileName = "BSA_export_"+ formatter.format(tDate)+".txt";
                            if(export(tFileName)){
                                Toast.makeText(this, "File exported as : " + tFileName, Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(this, "Something went wrong - failed to export", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }

                return true;

            default:

                return super.onOptionsItemSelected(item);
        }

    }

    private boolean checkFilePermission() {
        int result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestFilePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(this, "Access is required for creating data export file. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, AppConstants.PERMISSION_REQUEST_CODE);
        }
    }

    private void showAccountSummary() {

        if(!mViewModel.isAdminUser()){
            Toast.makeText(this, "Permission not available", Toast.LENGTH_SHORT).show();
            return;
        }

        HashMap<String, Student> tStudentMap = mViewModel.getAllStudentData();
        HashMap<String,Double> tFeeMap = mViewModel.getFeeData();

        AccountSummary tAccSumm =  new AccountSummary(tStudentMap, tFeeMap);
        String summaryText = tAccSumm.getAccountSummary();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setMessage(Html.fromHtml(summaryText.toString(),Html.FROM_HTML_MODE_LEGACY));
        }

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();


    }

    public boolean export(String vFileName){

        HashMap<String,Student> tStudentMap = mViewModel.getAllStudentData();
        Iterator keyIterator = tStudentMap.keySet().iterator();
        boolean tExportDone = false;

        if(tStudentMap != null) {
            try {
                File tExportFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), vFileName);
                FileOutputStream fos = new FileOutputStream(tExportFile);
                while (keyIterator.hasNext()) {
                    Student tStudent = tStudentMap.get((String)keyIterator.next());
                    String tExportLine = tStudent.getExportString()+"\n";
                    fos.write(tExportLine.getBytes());
                }
                fos.close();
                tExportDone = true;

            } catch (IOException e) {
                //TODO - error handling
                e.printStackTrace();
            }
        }
        return tExportDone;

    }

    private boolean checkPermissionforSMS() {

        boolean tReturn = false;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_DENIED) {

                String[] permissions = {Manifest.permission.SEND_SMS};
                requestPermissions(permissions, PERMISSION_REQUEST_CODE);

            }
        }
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        PERMISSION_REQUEST_CODE);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            // Permission has already been granted
            tReturn = true;
        }

        return tReturn;
    }

}
