package com.app.bsa;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.app.bsa.service.repository.AppConstants;
import com.app.bsa.service.repository.Student;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProviders;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Calendar;

public class StudentMaintActivity extends AppCompatActivity {

    EditText mFirstName;
    EditText mLastName;
    EditText mBatchName;
    EditText mContact;
    EditText mCFee;
    EditText mMonthsPaid;
    Spinner mMMSpinner;
    Spinner mYYYYSpinner;
    Spinner mBatchSpinner;
    Spinner mLevelSpinner;
    RadioGroup mBatchRadioGroup;
    RadioButton mRBExisting;
    RadioButton mRBNew;
    CheckBox mChkBoxJoiningFee;
    ImageButton mAddButton;
    ImageButton mUpdateButton;
    ImageButton mDeleteButton;
    FloatingActionButton mFabEdit;
    ArrayAdapter<CharSequence> mMMAdapter;
    ArrayAdapter<CharSequence> mYYYYAdapter;
    ArrayAdapter<CharSequence> mBatchListAdapter;
    ArrayAdapter<CharSequence> mLevelListAdapter;
    boolean mBExistingBatchSelected = true;

    private String mStudentId = "";
    private Student mStudentModel;
    private Context mContext;

    private ApplicationViewModel mViewModel;
    private String mCurrentMode = AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_maint);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mContext = getApplicationContext();

        FloatingActionButton fab = findViewById(R.id.fab_edit);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tMaintIntent = new Intent(mContext, StudentMaintActivity.class);
                tMaintIntent.putExtra(AppConstants.INTENT_KEY.ACTION, AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW);
                tMaintIntent.putExtra(AppConstants.INTENT_KEY.STUDENT_ID, mStudentId);
                mContext.startActivity(tMaintIntent);
            }
        });

        mViewModel = ViewModelProviders.of(this).get(ApplicationViewModel.class);

        mapFields();

        Intent tIntent = getIntent();
        mCurrentMode = tIntent.getExtras().getString(AppConstants.INTENT_KEY.ACTION);

        //Initialize model
        if(mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW)
                || mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_EDIT)){

            mStudentId = tIntent.getExtras().getString(AppConstants.INTENT_KEY.STUDENT_ID);
            mStudentModel = mViewModel.getStudentById(mStudentId);
            setFieldValuesFromModel();

            if(mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW)){
                disableEditing();
            }
        }
        else
        {
            mStudentModel = new Student();
        }

        setListenerActions();

        setButtonVisibility();
    }


    private void setFieldValuesFromModel(){

        //Called when edit or view mode
        //Set values from model

        String tFeeStatus = mStudentModel.Fee_status;

        if(tFeeStatus != null || !tFeeStatus.isEmpty()){
            //Assumption existing data will be in correct format if not empty
            int paidYYYY = Integer.parseInt(TextUtils.substring(tFeeStatus,3, 7));
            int paidMM = Integer.parseInt(TextUtils.substring(tFeeStatus,0, 2));
            String tYYYY = String.format("%04d",paidYYYY);
            String tMM = String.format("%02d",paidMM);

            mMMSpinner.setSelection(mMMAdapter.getPosition(tMM));
            mYYYYSpinner.setSelection(mYYYYAdapter.getPosition(tYYYY));
        }

        mFirstName.setText(mStudentModel.First_name);
        mLastName.setText(mStudentModel.Last_name);
        mBatchName.setText(mStudentModel.Batch_name);
        mContact.setText(mStudentModel.Contact);
        mCFee.setText(mStudentModel.Custom_fee);
        //At load - always will be existing batch
        mRBExisting.setChecked(true);
        mBatchSpinner.setSelection(mBatchListAdapter.getPosition(mStudentModel.Batch_name));
        mLevelSpinner.setSelection(mLevelListAdapter.getPosition(mStudentModel.Level));
        //Set Batch_name for extra caution
        mBatchName.setText(mStudentModel.Batch_name);
        mChkBoxJoiningFee.setChecked(mStudentModel.Joining_fee_paid);
        //mMonthsPaid.setText(String.format("%d",mStudentModel.Months_paid));

    }


    public LiveData<ArrayList<String>> getBatchNames(){

        return mViewModel.getBatchList();
    }

    private void mapFields() {

        mFirstName = findViewById(R.id.txt_edit_fname);
        mLastName = findViewById(R.id.txt_edit_lname);
        mBatchName = findViewById(R.id.txt_edit_bname);
        mContact = findViewById(R.id.txt_edit_contact);
        mCFee = findViewById(R.id.txt_edit_cfee);
        mMonthsPaid = findViewById(R.id.txt_months_paid);
        mMMSpinner = findViewById(R.id.sp_fee_month);
        mYYYYSpinner = findViewById(R.id.sp_fee_year);
        mBatchSpinner = findViewById(R.id.sp_batch_name);
        mAddButton = findViewById(R.id.btn_add_student1);
        mDeleteButton = findViewById(R.id.btn_delete_student1);
        mUpdateButton = findViewById(R.id.btn_update_student1);
        mBatchRadioGroup = findViewById(R.id.radioGroup);
        mRBExisting = findViewById(R.id.rb_existing_batch);
        mRBNew  = findViewById(R.id.rb_new_Batch);
        mLevelSpinner = findViewById(R.id.sp_level);
        mChkBoxJoiningFee = findViewById(R.id.chk_joining_fee);

        mFabEdit = findViewById(R.id.fab_edit);

        mMMAdapter = ArrayAdapter.createFromResource(this,
                R.array.months_array, android.R.layout.simple_spinner_item);
        mMMAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mMMSpinner.setAdapter(mMMAdapter);

        mYYYYAdapter = ArrayAdapter.createFromResource(this,
                R.array.years_array, android.R.layout.simple_spinner_item);
        mYYYYAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mYYYYSpinner.setAdapter(mYYYYAdapter);

        //final HashMap<String, Double> tFeeMap = mViewModel.getFeeData();
        mLevelListAdapter = new ArrayAdapter<CharSequence>(this,android.R.layout.simple_spinner_item,mViewModel.getSortedFeeNameList());
        mLevelListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mLevelSpinner.setAdapter(mLevelListAdapter);

        mBatchListAdapter = new ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item, mViewModel.getSortedBatchNameList());
        mBatchListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBatchSpinner.setAdapter(mBatchListAdapter);

        //Set default values
        Calendar cal1 = Calendar.getInstance();
        int paidMM = cal1.get(Calendar.MONTH)+1;
        int paidYYYY = cal1.get(Calendar.YEAR);
        String tYYYY = String.format("%04d",paidYYYY);
        String tMM = String.format("%02d",paidMM);

        mMMSpinner.setSelection(mMMAdapter.getPosition(tMM));
        mYYYYSpinner.setSelection(mYYYYAdapter.getPosition(tYYYY));

    }

    private void setButtonVisibility() {

        if(!mViewModel.isAdminUser()){
            //disable all buttons
            mAddButton.setEnabled(false);
            mAddButton.setVisibility(View.GONE);

            mDeleteButton.setEnabled(false);
            mDeleteButton.setVisibility(View.GONE);

            mUpdateButton.setEnabled(false);
            mUpdateButton.setVisibility(View.GONE);

            mFabEdit.setEnabled(false);
            mFabEdit.hide();

            mBatchRadioGroup.setVisibility(View.VISIBLE);
            mBatchSpinner.setVisibility(View.GONE);
            mRBNew.setVisibility(View.GONE);
            mRBExisting.setVisibility(View.GONE);
        }
        else{
            if (mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_VIEW)) {
                mAddButton.setEnabled(false);
                mAddButton.setVisibility(View.GONE);

                mDeleteButton.setEnabled(false);
                mDeleteButton.setVisibility(View.GONE);

                mUpdateButton.setEnabled(false);
                mUpdateButton.setVisibility(View.GONE);

                mFabEdit.setEnabled(true);
                mFabEdit.show();

                mBatchRadioGroup.setVisibility(View.VISIBLE);
                mRBNew.setVisibility(View.GONE);
                mRBExisting.setVisibility(View.GONE);
                mBatchName.setVisibility(View.VISIBLE);
                mBatchSpinner.setVisibility(View.GONE);
                mBExistingBatchSelected = true;

            } else if (mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_ADD)) {
                mAddButton.setEnabled(true);
                mAddButton.setVisibility(View.VISIBLE);

                mDeleteButton.setEnabled(false);
                mDeleteButton.setVisibility(View.GONE);

                mUpdateButton.setEnabled(false);
                mUpdateButton.setVisibility(View.GONE);

                mFabEdit.setEnabled(false);
                mFabEdit.hide();

                mBatchRadioGroup.setVisibility(View.VISIBLE);
                mRBNew.setVisibility(View.VISIBLE);
                mRBExisting.setVisibility(View.VISIBLE);
                mBatchRadioGroup.setEnabled(true);
                mRBNew.setEnabled(true);
                mRBExisting.setEnabled(true);

                mBatchName.setVisibility(View.GONE);
                mBatchSpinner.setVisibility(View.VISIBLE);
                mBExistingBatchSelected = true;

            } else if (mCurrentMode.equals(AppConstants.INTENT_VALUES.MAINT_ACTION_EDIT)) {
                mAddButton.setEnabled(false);
                mAddButton.setVisibility(View.GONE);

                mDeleteButton.setEnabled(true);
                mDeleteButton.setVisibility(View.VISIBLE);

                mUpdateButton.setEnabled(true);
                mUpdateButton.setVisibility(View.VISIBLE);

                mFabEdit.setEnabled(false);
                mFabEdit.hide();

                mBatchRadioGroup.setVisibility(View.VISIBLE);
                mRBNew.setVisibility(View.VISIBLE);
                mRBExisting.setVisibility(View.VISIBLE);
                mBatchRadioGroup.setEnabled(true);
                mRBNew.setEnabled(true);
                mRBExisting.setEnabled(true);
                mBatchName.setVisibility(View.GONE);
                mBatchSpinner.setVisibility(View.VISIBLE);
                mBExistingBatchSelected = true;

            } else {

                mAddButton.setEnabled(false);
                mAddButton.setVisibility(View.GONE);

                mDeleteButton.setEnabled(false);
                mDeleteButton.setVisibility(View.GONE);

                mUpdateButton.setEnabled(false);
                mUpdateButton.setVisibility(View.GONE);

                mFabEdit.setEnabled(false);
                mFabEdit.hide();

                mBatchRadioGroup.setVisibility(View.VISIBLE);
                mRBNew.setVisibility(View.GONE);
                mRBExisting.setVisibility(View.GONE);
                mBatchRadioGroup.setEnabled(false);
                mRBNew.setEnabled(false);
                mRBExisting.setEnabled(false);
            }
        }


    }

    private void disableEditing() {
        mFirstName.setEnabled(false);
        mLastName.setEnabled(false);
        mBatchName.setEnabled(false);
        mContact.setEnabled(false);
        mCFee.setEnabled(false);
        mMonthsPaid.setEnabled(false);
        mMMSpinner.setEnabled(false);
        mYYYYSpinner.setEnabled(false);
        mBatchSpinner.setEnabled(false);
        mBatchRadioGroup.setEnabled(false);
        mRBNew.setEnabled(false);
        mRBExisting.setEnabled(false);
        mLevelSpinner.setEnabled(false);
        mChkBoxJoiningFee.setEnabled(false);


    }


    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.rb_existing_batch:
                if (checked)
                    mBatchName.setVisibility(View.GONE);
                mBatchSpinner.setVisibility(View.VISIBLE);
                mBExistingBatchSelected = true;
                break;
            case R.id.rb_new_Batch:
                if (checked)
                    mBatchName.setVisibility(View.VISIBLE);
                mBatchSpinner.setVisibility(View.GONE);
                mBExistingBatchSelected = false;
                break;
        }
    }

    private void onClickUpdate() {

        new AlertDialog.Builder(this)
                .setTitle("Update Student")
                .setMessage("Confirm update?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        Student tStudent = new Student();
                        tStudent.First_name = mFirstName.getText().toString();
                        tStudent.Last_name = mLastName.getText().toString();
                        if(mBExistingBatchSelected){
                            tStudent.Batch_name = mBatchSpinner.getSelectedItem().toString();

                        }else{
                            tStudent.Batch_name = mBatchName.getText().toString();
                        }

                        tStudent.Fee_status = mMMSpinner.getSelectedItem().toString() + "/" + mYYYYSpinner.getSelectedItem().toString();
                        tStudent.Contact = mContact.getText().toString();
                        tStudent.Level = mLevelSpinner.getSelectedItem().toString();
                        tStudent.Custom_fee = mCFee.getText().toString();
                        tStudent.Joining_fee_paid = mChkBoxJoiningFee.isChecked();

                        String tMonthsPaid = mMonthsPaid.getText().toString();
                        int tNumMonthsPaid = 0;
                        try{
                            tNumMonthsPaid = Integer.parseInt(tMonthsPaid);
                        }catch(NumberFormatException e){
                            //CAnt do much here
                            Log.d("Maint", e.toString());
                        }
                        //tStudent.Months_paid = tNumMonthsPaid;

                        String tErr = validateStudentData(tStudent);
                        if(!tErr.isEmpty()){
                            showValidationErrors(tErr);
                        }else {
                            mViewModel.updateStudent(tStudent, mStudentId);
                            finish();
                        }
                    }})
                .setNegativeButton(android.R.string.no, null).show();

    }


    private void onClickDelete() {

        new AlertDialog.Builder(this)
                .setTitle("Delete Student")
                .setMessage("Confirm deletion?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        mViewModel.deleteStudent(mStudentId);
                        finish();
                    }})
                .setNegativeButton(android.R.string.no, null).show();

    }


    private void onClickAdd() {


        new AlertDialog.Builder(this)
                .setTitle("Add Student")
                .setMessage("Confirm Addition?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        Student tStudent = new Student();
                        tStudent.First_name = mFirstName.getText().toString();
                        tStudent.Last_name = mLastName.getText().toString();
                        if(mBExistingBatchSelected){
                            tStudent.Batch_name = mBatchSpinner.getSelectedItem().toString();

                        }else{
                            tStudent.Batch_name = mBatchName.getText().toString();
                        }
                        tStudent.Fee_status = mMMSpinner.getSelectedItem().toString() + "/" + mYYYYSpinner.getSelectedItem().toString();
                        tStudent.Contact = mContact.getText().toString();
                        tStudent.Level = mLevelSpinner.getSelectedItem().toString();
                        tStudent.Custom_fee = mCFee.getText().toString();
                        tStudent.Joining_fee_paid = mChkBoxJoiningFee.isChecked();

                        String tErr = validateStudentData(tStudent);
                        if(!tErr.isEmpty()){
                            showValidationErrors(tErr);
                        }else{
                            mViewModel.addStudent(tStudent);
                            finish();
                        }
                    }})
                .setNegativeButton(android.R.string.no, null).show();

    }

    private void showValidationErrors(String vErrorMessage){
        new AlertDialog.Builder(this)
                .setTitle("Validation Checks failed - Please address")
                .setMessage(vErrorMessage)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();
    }
    private String validateStudentData(Student vStudent){

        StringBuilder sb = new StringBuilder();
        if(vStudent.First_name.isEmpty()){
            sb.append("First name cannot be empty\n");
        }
        if(vStudent.Batch_name.isEmpty()){
            sb.append("Batch must be selected\n");
        }

        if(vStudent.Level.isEmpty() && vStudent.Custom_fee.isEmpty()){
            sb.append("Either Level or Custom Fee must be selected\n");
        }

        if(!vStudent.Level.isEmpty() && !vStudent.Custom_fee.isEmpty()){
            sb.append("Either Level or Custom Fee must be selected\n");
        }

        if(vStudent.Contact.isEmpty()){
            sb.append("Contact must be specified\n");
        }

        if(vStudent.Contact.length() != 10){
            sb.append("Contact must be 10 digits\n");
        }


        return sb.toString();
    }


    private void onClickEdit() {

        if (mViewModel.isAdminUser()) {
            //Enable deletes
            Intent tMaintIntent = new Intent(StudentMaintActivity.this, StudentMaintActivity.class);

            tMaintIntent.putExtra(AppConstants.INTENT_KEY.ACTION, AppConstants.INTENT_VALUES.MAINT_ACTION_EDIT);
            tMaintIntent.putExtra(AppConstants.INTENT_KEY.STUDENT_ID, mStudentId);
            startActivity(tMaintIntent);
            finish();
        }
    }

    private void setListenerActions() {
        mFabEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickEdit();
            }
        });

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onClickAdd();
            }
        });

        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickDelete();
            }
        });

        mUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onClickUpdate();
            }
        });

    }
}
