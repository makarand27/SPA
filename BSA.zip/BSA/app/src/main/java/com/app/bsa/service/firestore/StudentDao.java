package com.app.bsa.service.firestore;

public class StudentDao {

    public String First_name;
    public String Last_name;
    public String Contact;
    public String Batch_name;
    public String Level;
    public String Fee_status;
    public String Custom_fee;
    public boolean Joining_fee_paid;
}
